<section id="titulo">
            <h1>Usuários cadastrados</h1>
</section>
<a href="../model/exibirfotos.php">Fotos</a>
